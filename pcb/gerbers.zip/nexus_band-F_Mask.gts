%TF.GenerationSoftware,KiCad,Pcbnew,10.0.8*%
%TF.CreationDate,2026-11-16T17:06:03+05:30*%
%TF.ProjectId,nexus_band,6e657875-735f-4626-916e-642e6b696361,A*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.8) date 2026-11-16 17:06:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,0.500000*%
%ADD11C,0.900000*%
G04 APERTURE END LIST*
D10*
%TO.C,MK1*%
X182760000Y-84400000D03*
%TD*%
%TO.C,MK2*%
X182760000Y-115000000D03*
%TD*%
D11*
%TO.C,SW3*%
X159500000Y-118180000D03*
X156500000Y-118180000D03*
%TD*%
M02*
